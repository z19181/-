PyQt5 distributed via PyPI
--------------------------

See `GitHub repository`_ for more information.

.. _`GitHub repository`: https://github.com/pyqt/python-qt5
